package com.skteam.appnewpro.models;

import java.util.List;

public class ImageSlider extends Base_Response {
    public String image;
    public List<ImageSlider> res;
}
