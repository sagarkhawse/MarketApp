package com.skteam.appnewpro.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.skteam.appnewpro.R;
import com.skteam.appnewpro.api.RetrofitApi;
import com.skteam.appnewpro.api.RetrofitClient;
import com.skteam.appnewpro.databinding.ActivityLoginBinding;
import com.skteam.appnewpro.simpleclasses.Constants;
import com.skteam.appnewpro.simpleclasses.Functions;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivityTest";
    private Activity activity;
    private ActivityLoginBinding binding;
    private FirebaseAuth mAuth;
    private RetrofitApi mService;
    private FirebaseUser mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        activity = this;
        mService = RetrofitClient.getAPI();
        FirebaseApp.initializeApp(activity);
        mAuth = FirebaseAuth.getInstance();

        mUser = mAuth.getCurrentUser();
        if (mUser!=null){
            startActivity(new Intent(activity,HomeActivity.class));
            finish();
        }

        initViewsClicks();
    }

    private void initViewsClicks() {
        binding.etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() == 10) {
                    Functions.hideSoftKeyboard(activity);
                openOtpActivity();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void openOtpActivity() {
        Intent intent = new Intent(activity,OtpActivity.class);
        intent.putExtra(Constants.COUNTRY_CODE,"+91");
intent.putExtra(Constants.PHONE,binding.etPhone.getText().toString());
        startActivity(intent);
    }
}