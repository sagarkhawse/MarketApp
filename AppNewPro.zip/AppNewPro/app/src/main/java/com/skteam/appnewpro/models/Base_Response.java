package com.skteam.appnewpro.models;

import java.io.Serializable;

public class Base_Response implements Serializable {
    public String code, error_msg;
}
