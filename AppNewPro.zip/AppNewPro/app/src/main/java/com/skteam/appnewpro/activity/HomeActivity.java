package com.skteam.appnewpro.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.skteam.appnewpro.R;
import com.skteam.appnewpro.api.RetrofitApi;
import com.skteam.appnewpro.api.RetrofitClient;
import com.skteam.appnewpro.databinding.ActivityHomeBinding;
import com.skteam.appnewpro.databinding.ActivityLoginBinding;
import com.skteam.appnewpro.fragments.HomeFragment;

public class HomeActivity extends AppCompatActivity {
    private static final String TAG = "HomeActivityTest";
    private Activity activity;
    private ActivityHomeBinding binding;
    private FirebaseAuth mAuth;
    private RetrofitApi mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        activity = this;
        mService = RetrofitClient.getAPI();
        FirebaseApp.initializeApp(activity);
        mAuth = FirebaseAuth.getInstance();
setFragment(new HomeFragment(),"home_fragment");
        initViewsClicks();
    }

    private void initViewsClicks() {

    }

    public void setFragment(Fragment fragment, String name) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft = ft.replace(R.id.fragment_container, fragment, name);
        ft.commit();
    }

}