package com.skteam.appnewpro.models;

import java.util.List;

public class Post extends Base_Response{

public int id;
    public String user_id , post_id, media, caption, hashtag , location , created_at ;
    public List<Post> res;
    public List<Post> media_files;
    public String  user_name, full_name, profile_pic;
    public String views, like_count,comment_count,liked, type;
    public String title, description, image, contact_number, email;


}
