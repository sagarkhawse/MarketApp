package com.skteam.appnewpro.simpleclasses;

public class Constants {

    public static final String SUCCESS_CODE = "200";
    public static final String COUNTRY_CODE = "country_code";
    public static final String PHONE = "phone";
}
