package com.skteam.appnewpro.simpleclasses;

import android.content.SharedPreferences;


public class Variables {

    private final static String DOMAIN = "https://androappdev.xyz/";
    private final static String PATH = "NewApp/";
    public final static String BASE_URL = DOMAIN + PATH;
    public final static String api = "index.php?p=";

    public final static String my_shared_pref = "my_shared_pref";
    public static SharedPreferences sharedPreferences;
    public static SharedPreferences.Editor editor;
    public final static String user_name = "user_name";
    public final static String email = "email";
    public final static String phone = "phone";
    public final static String user_id = "user_id";
    public final static String user_dp = "user_dp";



}
