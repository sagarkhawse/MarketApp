package com.skteam.appnewpro.api;


import com.skteam.appnewpro.models.Category;
import com.skteam.appnewpro.models.ImageSlider;
import com.skteam.appnewpro.models.Post;
import com.skteam.appnewpro.simpleclasses.Variables;

import io.reactivex.Single;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitApi {

    @GET(Variables.api + "show_image_slider")
    Call<ImageSlider> show_image_slider();

    @GET(Variables.api + "show_category")
    Call<Category> show_category();

    @FormUrlEncoded
    @POST(Variables.api + "show_posts")
    Call<Post> show_posts(@Field("last_id") int last_id,
                            @Field("user_id") String user_id,
                            @Field("action") String action);

}
