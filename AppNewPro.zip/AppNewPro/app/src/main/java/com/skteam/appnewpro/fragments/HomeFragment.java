package com.skteam.appnewpro.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.skteam.appnewpro.R;
import com.skteam.appnewpro.adapters.CategoryAdapter;
import com.skteam.appnewpro.adapters.HomeSliderAdapter;
import com.skteam.appnewpro.adapters.PostAdapter;
import com.skteam.appnewpro.api.RetrofitApi;
import com.skteam.appnewpro.api.RetrofitClient;
import com.skteam.appnewpro.databinding.FragmentHomeBinding;
import com.skteam.appnewpro.models.Category;
import com.skteam.appnewpro.models.ImageSlider;
import com.skteam.appnewpro.models.Post;
import com.skteam.appnewpro.simpleclasses.Constants;
import com.skteam.appnewpro.simpleclasses.Functions;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeFragment extends Fragment {
    private static final String TAG = "HomeFragment";
    private Context context;
    private FragmentHomeBinding binding;
    private RetrofitApi mService;


    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        mService = RetrofitClient.getAPI();
        context = getContext();

        initImageSlider();
        initCategory();
        initServices();
        return view;
    }

    private void initServices() {
mService.show_posts(0, FirebaseAuth.getInstance().getCurrentUser().getUid(),"fetch_all_post")
    .enqueue(new Callback<Post>() {
        @Override
        public void onResponse(Call<Post> call, Response<Post> response) {

   binding.rvServices.setAdapter(new PostAdapter(context,response.body().res));
        }

        @Override
        public void onFailure(Call<Post> call, Throwable t) {

        }
    });
    }

    private void initImageSlider() {
    mService.show_image_slider()
            .enqueue(new Callback<ImageSlider>() {
                @Override
                public void onResponse(Call<ImageSlider> call, Response<ImageSlider> response) {
                    if (response.body()!=null){
                        if (response.body().code.equals(Constants.SUCCESS_CODE)){
                            HomeSliderAdapter adapter = new HomeSliderAdapter(context,response.body().res);
                            binding.imageSlider.setSliderAdapter(adapter);
                        }
                    }
                }

                @Override
                public void onFailure(Call<ImageSlider> call, Throwable t) {

                }
            });
    }

    private void initCategory() {
    mService.show_category()
            .enqueue(new Callback<Category>() {
                @Override
                public void onResponse(Call<Category> call, Response<Category> response) {
                    Log.d(TAG, "onResponse: "+response.body().code);
                    if (response.body()!=null){
                        if (response.body().code.equals(Constants.SUCCESS_CODE)){
                            CategoryAdapter adapter = new CategoryAdapter(context,response.body().res);
                            binding.rvCategories.setAdapter(adapter);
                        }
                    }
                }

                @Override
                public void onFailure(Call<Category> call, Throwable t) {
                    Functions.ShowToast(context,t.getMessage());
                }
            });
    }
}