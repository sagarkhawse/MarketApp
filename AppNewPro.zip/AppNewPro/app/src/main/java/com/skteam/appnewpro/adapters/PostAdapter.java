package com.skteam.appnewpro.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.bumptech.glide.Glide;
import com.skteam.appnewpro.R;
import com.skteam.appnewpro.models.Post;
import com.skteam.appnewpro.simpleclasses.Variables;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import ru.tinkoff.scrollingpagerindicator.ScrollingPagerIndicator;


public class PostAdapter extends RecyclerView.Adapter<PostAdapter.DataViewHolder> {
    private static final String TAG = "PostAdapterTest";
    private Context context;
private List<Post> list;
    private SnapHelper helper;


    public PostAdapter(Context context, List<Post> list) {
        this.context = context;
        this.list = list;


    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_service, parent, false);
        return new DataViewHolder(view);
    }

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForDrawables"})
    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        Post data = list.get(position);

Glide.with(context).load(Variables.BASE_URL+data.image).into(holder.imageView);
holder.contact_number.setText("Contact :- " + data.contact_number);
        holder.email.setText("Email :- " + data.contact_number);
        holder.title.setText(data.title);
        holder.description.setText(data.description);

    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    static class DataViewHolder extends RecyclerView.ViewHolder {
        private RecyclerView recyclerView;
private ImageView imageView;
        private TextView title, description, contact_number, email;


        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
imageView = itemView.findViewById(R.id.imageView);
            title = itemView.findViewById(R.id.tvTitle);
            description = itemView.findViewById(R.id.tvDescription);
            contact_number = itemView.findViewById(R.id.tvContactNum);
            email = itemView.findViewById(R.id.tvEmail);

        }
    }





}
