package com.skteam.appnewpro.models;

import java.util.List;

public class Category extends Base_Response{

public int id;
public String image, title;
public List<Category> res;
}

